/*!
 * 
 * admin的配置段
 * * */

-- 数据库配置开始
    -- 数据库链接字符串
INSERT INTO config_detail (akey,avalue,application,profile,label,mwtype) VALUES ('spring.datasource.url','jdbc:mysql://sunboxdev.mysql.database.azure.com/sdpms?useUnicode=true&characterEncoding=UTF-8','sdp-admin','test','master','db');
    -- 数据库用户名 需要使用tools 加密
INSERT INTO config_detail (akey,avalue,application,profile,label,mwtype) VALUES ('spring.datasource.username','olL24gc5aKs6g/GUNFVYYA==','sdp-admin','test','master','db');
    -- 数据库密码 需使用tools加密
INSERT INTO config_detail (akey,avalue,application,profile,label,mwtype) VALUES ('spring.datasource.password','UR4S4j5mZOUjzBtohslzhQ==','sdp-admin','test','master','db');
    -- 表分片配置，默认即可
INSERT INTO config_detail (akey,avalue,application,profile,label,mwtype) VALUES ('spring.datasource.tableconfig','[]','sdp-admin','test','master','db');
    -- 是否打印sql
INSERT INTO config_detail (akey,avalue,application,profile,label,mwtype) VALUES ('spring.datasource.showsql','false','sdp-admin','test','master','db');
-- 数据库配置结束

-- servicebus配置开始
INSERT INTO config_detail (akey,avalue,application,profile,label,mwtype) VALUES ('azure.servicebus.connectionString','sb://sdpservicebus.servicebus.windows.net/;SharedAccessKeyName=RootManageSharedAccessKey;SharedAccessKey=04PBREXd+rS3FLMLmzKnyGQ0QDihtE2eXX56zAMwlVI=','sdp-admin','test','master','db');
INSERT INTO config_detail (akey,avalue,application,profile,label,mwtype) VALUES ('azure.servicebus.topicName','sdpdevqueue','sdp-admin','test','master','db');
INSERT INTO config_detail (akey,avalue,application,profile,label,mwtype) VALUES ('azure.servicebus.subName','','sdp-admin','test','master','db');
-- servicebus配置开始

-- keyvault 配置开始
INSERT INTO config_detail (akey,avalue,application,profile,label,mwtype) VALUES ('keyvault.uri','https://sdpdevkeyvault.vault.azure.net/','sdp-admin','test','master','db');
INSERT INTO config_detail (akey,avalue,application,profile,label,mwtype) VALUES ('keyvault.clientid','4df49372-c3f9-4841-8f16-bc6d971548e0','sdp-admin','test','master','db');
INSERT INTO config_detail (akey,avalue,application,profile,label,mwtype) VALUES ('keyvault.clientsecret','0oH8Q~6XcI.KasOQzkdAKIto4qh9Gqp93tktZa6P','sdp-admin','test','master','db');
INSERT INTO config_detail (akey,avalue,application,profile,label,mwtype) VALUES ('keyvault.tenantid','e446233b-677e-4f72-aba3-4ef2858fead2','sdp-admin','test','master','db');
-- keyvault 配置结束

-- 消息发送客户端配置开始
INSERT INTO config_detail (akey,avalue,application,profile,label,mwtype) VALUES ('admin.message.clientname','p1','sdp-admin','test','master','db');
-- 消息发送客户端配置结束

-- redis 配置开始
INSERT INTO config_detail (akey,avalue,application,profile,label,mwtype) VALUES ('mredis.lock.port','UoEIHxGhjqM=','sdp-admin','test','master','db');
INSERT INTO config_detail (akey,avalue,application,profile,label,mwtype) VALUES ('mredis.lock.address','LGUlLzOmVLvQ9AQ7pd8b/FHrH2GrHs2uzeDUovnVENNsQ9VTr+twcA==','sdp-admin','test','master','db');
INSERT INTO config_detail (akey,avalue,application,profile,label,mwtype) VALUES ('mredis.lock.password','XQa221Z9MiqJCYqGaw8CxlVVQ7kOLT+SPZpBNS1Setq9oldLPlj924REUXwuuGgc','sdp-admin','test','master','db');
INSERT INTO config_detail (akey,avalue,application,profile,label,mwtype) VALUES ('mredis.usessl','0','sdp-admin','test','master','db');
-- redis 配置结束


/*! 
 * 
 * Compose的配置段
 * 
 * */
 -- 数据库配置开始
  --数据库链接字符串
INSERT INTO config_detail (akey,avalue,application,profile,label,mwtype) VALUES ('spring.datasource.url','jdbc:mysql://sunboxdev.mysql.database.azure.com/sdpms?useUnicode=true&characterEncoding=UTF-8','sdp-compose','test','master','db');
  -- 数据库用户名 需要使用tools 加密
INSERT INTO config_detail (akey,avalue,application,profile,label,mwtype) VALUES ('spring.datasource.username','olL24gc5aKs6g/GUNFVYYA==','sdp-compose','test','master','db');
  -- 数据库密码 需要使用tools加密
INSERT INTO config_detail (akey,avalue,application,profile,label,mwtype) VALUES ('spring.datasource.password','UR4S4j5mZOUjzBtohslzhQ==','sdp-compose','test','master','db');
  -- 表分片配置，默认即可
INSERT INTO config_detail (akey,avalue,application,profile,label,mwtype) VALUES ('spring.datasource.tableconfig','[]','sdp-compose','test','master','db');
  -- 是否打印sql
INSERT INTO config_detail (akey,avalue,application,profile,label,mwtype) VALUES ('spring.datasource.showsql','false','sdp-compose','test','master','db');
-- 数据库配置结束

-- servicebus 配置开始
INSERT INTO config_detail (akey,avalue,application,profile,label,mwtype) VALUES ('azure.servicebus.connectionString','Endpoint=sb://sunboxdev.servicebus.windows.net/;SharedAccessKeyName=RootManageSharedAccessKey;SharedAccessKey=FIv3Zwbg3TFADRoQmYQ3MMdc2Kn1GYa/0RTDlUkVzdQ=','sdp-compose','test','master','db');
INSERT INTO config_detail (akey,avalue,application,profile,label,mwtype) VALUES ('azure.servicebus.topicName','sunboxdevtopic','sdp-compose','test','master','db');
INSERT INTO config_detail (akey,avalue,application,profile,label,mwtype) VALUES ('azure.servicebus.subName','topic01','sdp-compose','test','master','db');
-- servicebus 配置结束

-- 调度引擎消息配置开始
  -- 消息客户端配置 只需要修改 connettiongString topicename subname
  -- p1 和 c1 中使用的topic，为调度引擎使用的topic需要保持一致
  -- sdp_rm_job_client 为 创建和销毁虚拟机消息通知topic
  
INSERT INTO config_detail (akey,avalue,application,profile,label,mwtype) VALUES ('azure.servicebus.configs','[
  {
    "name": "p1",
    "connectionString":"Endpoint=sb://sunboxdev.servicebus.windows.net/;SharedAccessKeyName=RootManageSharedAccessKey;SharedAccessKey=FIv3Zwbg3TFADRoQmYQ3MMdc2Kn1GYa/0RTDlUkVzdQ=",
    "type": "producer",
    "topicName": "sunboxdevtopic",
    "subName": "topic01"
  },
  {
    "name": "c1",
    "type": "consumer",
    "connectionString":"Endpoint=sb://sunboxdev.servicebus.windows.net/;SharedAccessKeyName=RootManageSharedAccessKey;SharedAccessKey=FIv3Zwbg3TFADRoQmYQ3MMdc2Kn1GYa/0RTDlUkVzdQ=",    
    "topicName": "sunboxdevtopic",
    "subName": "topic01",
    "callback": "PlanExecService@composeExecute"
  },
  {
    "name": "sdp_rm_job_client",
    "type": "consumer",
    "connectionString":"Endpoint=sb://sbisddevaks.servicebus.windows.net/;SharedAccessKeyName=sdp-client-policy;SharedAccessKey=iuRWw4LLzYU4XWykgfBe6hNKjtBKda/nCg4FtWWNtAg=",    
    "topicName": "sdp_rm_job_event_bus",
    "subName": "sdp_rm_job_client",
    "callback": "PlanExecService@receiveVmJobMessage"
  }
]','sdp-compose','test','master','db');
INSERT INTO config_detail (akey,avalue,application,profile,label,mwtype) VALUES ('compose.message.clientname','p1','sdp-compose','test','master','db');
  -- 是否在日志中打印消息，1 打开 0 关闭
INSERT INTO config_detail (akey,avalue,application,profile,label,mwtype) VALUES ('azure.servicebus.showMessage','1','sdp-compose','test','master','db');
  -- 活动超时时间配置
INSERT INTO config_detail (akey,avalue,application,profile,label,mwtype) VALUES ('activity.timeout','1800','sdp-compose','test','master','db');
-- 调度引擎消息配置结束

-- 虚拟机开通资源配置开始
  -- 接口地址
INSERT INTO config_detail (akey,avalue,application,profile,label,mwtype) VALUES ('azure.request.url','http://20.125.69.82:8081','sdp-compose','test','master','db');
  -- hostname后缀
INSERT INTO config_detail (akey,avalue,application,profile,label,mwtype) VALUES ('vm.hostnamesuffix','.sdp-sit.isd-dev-aks.com','sdp-compose','test','master','db');
  -- 默认用户名
INSERT INTO config_detail (akey,avalue,application,profile,label,mwtype) VALUES ('vm.username','azureuser','sdp-compose','test','master','db');
  -- private 域
INSERT INTO config_detail (akey,avalue,application,profile,label,mwtype) VALUES ('vm.domain','sdp-sit.isd-dev-aks.com','sdp-compose','test','master','db');
-- 虚拟机开通资源配置结束

-- redis配置开始
  -- 端口号需要使用tools加密
INSERT INTO config_detail (akey,avalue,application,profile,label,mwtype) VALUES ('mredis.lock.port','UoEIHxGhjqM=','sdp-compose','test','master','db');
  -- 地址 需要使用tools加密
INSERT INTO config_detail (akey,avalue,application,profile,label,mwtype) VALUES ('mredis.lock.address','LGUlLzOmVLvQ9AQ7pd8b/FHrH2GrHs2uzeDUovnVENNsQ9VTr+twcA==','sdp-compose','test','master','db');
  -- 密码 需要使用tools加密
INSERT INTO config_detail (akey,avalue,application,profile,label,mwtype) VALUES ('mredis.lock.password','XQa221Z9MiqJCYqGaw8CxlVVQ7kOLT+SPZpBNS1Setq9oldLPlj924REUXwuuGgc','sdp-compose','test','master','db');
  -- 是否使用ssl 目前只支持 0
INSERT INTO config_detail (akey,avalue,application,profile,label,mwtype) VALUES ('mredis.usessl','0','sdp-compose','test','master','db');
-- redis配置结束

-- ansible 配置开始
  -- ansible接口地址
INSERT INTO config_detail (akey,avalue,application,profile,label,mwtype) VALUES ('playbook.request.url','http://20.106.67.92:8091','sdp-compose','test','master','db');
  -- 脚本blob地址
INSERT INTO config_detail (akey,avalue,application,profile,label,mwtype) VALUES ('sdp.wgetpath','sasdpscriptstmp.blob.core.windows.net','sdp-compose','test','master','db');
-- ansible 配置结束

-- keyvault 配置开始
INSERT INTO config_detail (akey,avalue,application,profile,label,mwtype) VALUES ('keyvault.uri','https://sdpdevkeyvault.vault.azure.net/','sdp-compose','test','master','db');
INSERT INTO config_detail (akey,avalue,application,profile,label,mwtype) VALUES ('keyvault.clientid','4df49372-c3f9-4841-8f16-bc6d971548e0','sdp-compose','test','master','db');
INSERT INTO config_detail (akey,avalue,application,profile,label,mwtype) VALUES ('keyvault.clientsecret','0oH8Q~6XcI.KasOQzkdAKIto4qh9Gqp93tktZa6P','sdp-compose','test','master','db');
INSERT INTO config_detail (akey,avalue,application,profile,label,mwtype) VALUES ('keyvault.tenantid','e446233b-677e-4f72-aba3-4ef2858fead2','sdp-compose','test','master','db');
-- keyvault 配置结束

-- ambari配置开始
  -- 是否打印debug日志
INSERT INTO config_detail (akey,avalue,application,profile,label,mwtype) VALUES ('ambari.api.debug','1','sdp-compose','test','master','db');
  -- 默认用户名
INSERT INTO config_detail (akey,avalue,application,profile,label,mwtype) VALUES ('ambari.default.user','admin','sdp-compose','test','master','db');
  -- 默认密码
INSERT INTO config_detail (akey,avalue,application,profile,label,mwtype) VALUES ('ambari.default.pwd','admin','sdp-compose','test','master','db');
-- ambari 配置结束


